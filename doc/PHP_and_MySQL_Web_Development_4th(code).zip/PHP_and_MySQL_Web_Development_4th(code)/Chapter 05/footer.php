<!-- page footer -->
  <table width="100%" bgcolor="black" cellpadding="12" border="0">
  <tr>
    <td>
      <p class="foot">&copy; TLA Consulting Pty Ltd.</p>
      <p class="foot">Please see our <a href="legal.php">
      legal information page</a></p>
    </td>
  </tr>
  </table>
</body>
</html>

